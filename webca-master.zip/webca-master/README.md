# WeBCa Implementation

This repository houses the example implementation of FReCon, written by contributors from West Lafayette Junior/Senior High School, Brainerd High School, and Carmel High School.

## Currently-Supported Browsers

Any browsers that support jQuery v2.1.1, d3 v3.4.9, and Bootstrap v3.2.0 should not experience errors with our upstream packages.
However, certain browsers do not support the IndexedDB WebAPI, which is required for offline data storage.
Below is a rough list of the supported browsers:

 * Chrome
 * Chrome (Incognito)
 * Firefox

More may be added at a later date.

# Note About Testing

When testing, be sure to clear all your browser cache and offline data. It's a good idea to run the browser in private mode or incognito mode for testing so that way old versions of pages aren't cached.

If you run tests in private/incognito mode, after every change you'll have to close the "private" instance and restart it to see changes. Private/incognito mode will cache for as long as that instance is open.

An alternate method of testing, using Firefox and Firebug, is to click on the "Net" dropdown and disable caching.
Then, whenever you restart the page the new code will be loaded.
Be sure to enable caching again after you are done testing though, as it makes your internet browsing smoother.

### Firefox

IndexedDB will fail if you are testing in Private Mode in Firefox. This is just limitation of Firefox. Use Chrome's Incognito mode when testing IndexedDB features if you are using a private/incognito mode.
