const DEFENSES = [
    {
        display: "Portcullis",
        name: "portcullisCrossed"
    }, {
        display: "Cheval De Frise",
        name: "chevalCrossed"
    }, {
        display: "Moat",
        name: "moatCrossed"
    }, {
        display: "Ramparts",
        name: "rampartsCrossed"
    }, {
        display: "Drawbridge",
        name: "drawbridgeCrossed"
    }, {
        display: "Sally Port",
        name: "sallyportCrossed"
    }, {
        display: "Rock Wall",
        name: "rockwallCrossed"
    }, {
        display: "Rough Terrain",
        name: "roughterrainCrossed"
    }, {
		display:" Low Bar",
		name: "lowbarCrossed"
	}
];
