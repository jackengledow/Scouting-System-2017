require "frecon"
require "manifesto"
require "fileutils"
require "sinatra/base"

def get_next_file_number(dirname)
	glob = Dir.glob(File.join(dirname, "*"))

	basenames = glob.map do |filename|
		{filename: filename, basename: File.basename(filename, ".*")}
	end

	sorted_basenames = basenames.sort do |a, b|
		a[:basename].length <=> b[:basename].length
	end.sort do |a, b|
		a[:basename].to_i <=> b[:basename].to_i
	end

	last_number = (sorted_basenames.last ? sorted_basenames.last[:basename] : -1).to_i

	last_number + 1
end

def images_routes(team = nil)
	if team
		image_files = Dir.glob(File.join(File.dirname(__FILE__), "public", "images", team, "*.*"))

		image_routes = image_files.map do |image_file|
			File.join("", "images", File.basename(File.dirname(image_file)), File.basename(image_file))
		end.to_a

		return image_routes
	else
		image_routes = {}

		Dir.glob(File.join(File.dirname(__FILE__), "public", "images", "*")).select do |file|
			File.directory?(file)
		end.each do |team_directory|
			basename = File.basename(team_directory)

			image_routes[basename] =
				(Dir.glob(File.join(team_directory, "*.*")).map do |image_file|
					 File.join("", "images", basename, File.basename(image_file))
				 end.to_a)
		end

		return image_routes
	end
end

class WeBCaServer < Sinatra::Base
	configure do
		$defaults ||= {}

		# Set the current competition if possible.
		current_competition = FReCon::Competition.max { |comp| comp.records.count }

		# Set "competition" default to the name of the current competition if selected.
		$defaults["competition"] = current_competition if current_competition
	end

	before do
		request.body.rewind
	end

	put "/defaults" do
		content_type "application/json"

		$defaults ||= {}

		# Rewind the request body,
		# in case somebody has already
		# accessed it.
		request.body.rewind

		begin
			# Parse the request body.
			diffhash = JSON.parse(request.body.read)

			# For each key in the diffhash,
			# change the value in the $defaults hash
			# accordingly.
			#
			# This approach does not get rid of
			# existing data.
			diffhash.keys.each do |key|
				$defaults[key] = diffhash[key]
			end
		rescue JSON::ParserError => e
			return [422, { "errors" => [e.message, e.backtrace].flatten }.to_json]
		end

		# Respond with the updated
		# $defaults hash.
		$defaults.to_json
	end

	delete "/defaults" do
		content_type "application/json"

		$defaults = {}
	end

	get "/defaults" do
		content_type "application/json"

		$defaults.to_json
	end

	get "/manifest" do
		headers "Content-Type" => "text/cache-manifest"

		Manifesto.cache network_includes: ["*", "ping", "/images", images_routes.keys.map{|k|"/images/#{k}"}].flatten, timestamp: false
	end

	get "/images" do
		content_type "application/json"

		JSON.generate(images_routes)
	end

	get "/images/:team" do |team|
		content_type "application/json"

		JSON.generate(images_routes(team))
	end

	post "/images/:team" do |team|
		content_type "application/json"

		team_directory = File.join(File.dirname(__FILE__), "public", "images", team)

		request.body.rewind

		data = request.body.read

		data_index = data.index('base64') + 7
		file_data = data.slice(data_index, data.length)
		decoded_image = Base64.decode64(file_data)

		mime_index = data.index('data:') + 5
		mime_end_index = data.index(';') - 1
		mime_type = data[(mime_index..mime_end_index)]

		file_number = get_next_file_number(team_directory)
		file_extension = nil

		case mime_type
		when "image/png"
			file_extension = ".png"
		when "image/jpeg"
			file_extension = ".jpeg"
		else
			file_extension = ".something"
		end

		output_file = "#{file_number}#{file_extension}"

		if !File.directory?(team_directory)
			FileUtils.mkdir_p(team_directory)
		end

		open(File.join(team_directory, output_file), "wb") do |io|
			io.write(decoded_image)
		end

		Dir.glob(File.join(team_directory, "*.*"))
	end

	get "/ping" do
		content_type "text/plain"

		""
	end

	get "/" do
		redirect to "/index.html"
	end
end
